﻿using Microsoft.Win32;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        //lista obrazow
        private List<string> imageFiles;
        
        //aktualny indeks obrazka
        private int currentIndex = 0;

        //flaga stanu pokazu
        private bool isSlideshowRunning = false;

        //token do przerywania
        private CancellationTokenSource cancellationTokenSource;

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void btnSelectFiles_Click(object sender, RoutedEventArgs e)
        {
            var OpenFileDialog = new OpenFileDialog
            {
                Filter = "Pliki graficzne (*.jpg; *.png; *.bmp; *.gif; *.jpeg)|*.jpg; *.png; *.bmp; *.gif; *.jpeg",
                Multiselect = true
            };

            if (OpenFileDialog.ShowDialog() == true)
            {
                imageFiles = OpenFileDialog.FileNames.ToList();
                if (imageFiles.Any())
                {
                    btnStartStop.IsEnabled = true;
                    cancellationTokenSource?.Cancel();
                    cancellationTokenSource = new CancellationTokenSource();
                    isSlideshowRunning = true;
                    btnStartStop.Content = "stop";
                    await StartShow(cancellationTokenSource.Token);
                }
            }else
            {
                MessageBox.Show("nie wybrano pliku do pokazu xddd", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task StartShow(CancellationToken token)
        {
            while (!token.IsCancellationRequested && imageFiles.Any()){
                DisplayImage(imageFiles[currentIndex]);

                try
                {
                    await Task.Delay(3000);
                }
                catch (Exception ex)
                {
                    return;
                }
                currentIndex = (currentIndex + 1) % imageFiles.Count;
            }
        }

        private void DisplayImage(string imagePath)
        {
            try
            {
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(imagePath);
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.EndInit();
                imageControl.Source = bitmap;
            }
            catch (Exception ex) {
                MessageBox.Show("problem z wczytaniem obrazu xdd", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnStartStop_Click(object sender, RoutedEventArgs e)
        {
            if (isSlideshowRunning)
            {
                cancellationTokenSource?.Cancel();
                isSlideshowRunning = false;
                btnStartStop.Content = "start";
            }
            else
            {
                cancellationTokenSource = new CancellationTokenSource();
                isSlideshowRunning= true;
                btnStartStop.Content = "stop";
                _ = StartShow(cancellationTokenSource.Token);
            }
        }
    }
}