import { Injectable, signal, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {
  // Dependency Injection za pomocą funkcji inject().
  // Eliminuje to potrzebę pisania tradycyjnego konstruktora.
  private http = inject(HttpClient);
  private router = inject(Router);
  
  // Angular Signals: Reaktywne zarządzanie stanem roli użytkownika.
  // Inicjalizacja pobiera wartość bezpośrednio z localStorage, co zapobiega
  // "wylogowaniu" użytkownika po odświezeniu strony
  userRole = signal<string | null>(localStorage.getItem('role'));

  login(credentials: any) {
    // Wykonanie żądania POST do API.
    // pipe(tap(...)) pozwala na wykonanie "efektu ubocznego" (zapisu danych),
    // nie modyfikując samego strumienia danych, który wraca do komponentu.
    return this.http.post<any>('http://localhost:3000/api/login', credentials).pipe(
      tap(res => {
        // Persystencja danych: zapisujemy token JWT i rolę w pamięci przeglądarki.
        localStorage.setItem('token', res.token);
        localStorage.setItem('role', res.role);
        
        // Aktualizacja sygnału: wszystkie komponenty obserwujące userRole() 
        // (np. Navbar) zostaną natychmiast przeładowane
        this.userRole.set(res.role);
      })
    );
  }

  logout() {
    // Czyszczenie stanu układu:
    localStorage.clear();        // Usuwamy tokeny z pamięci trwałej.
    this.userRole.set(null);     // Resetujemy sygnał 
    this.router.navigate(['/login']); // Przekierowanie do stanu początkowego.
  }

  getToken() {
    // Prosta metoda dostępowa (getter) używana głównie przez Interceptor
    // do dołączania nagłówka Authorization do żądań HTTP.
    return localStorage.getItem('token');
  }
}