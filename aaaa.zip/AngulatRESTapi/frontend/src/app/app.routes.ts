// src/app/app.routes.ts
import { Routes } from '@angular/router';
import { Login } from './login/login';
import { Admin } from './admin/admin';
import { UserProfile } from './user-profile/user-profile';

export const routes: Routes = [
  // Stan 1: Jawne punkty wejścia
  { path: 'login', component: Login },
  { path: 'admin', component: Admin },
  
  // Stan 2: Aliasy (Dwa adresy wskazują na ten sam komponent profilu)
  // Dobra praktyka: 'user' dla logiki biznesowej, 'profile' dla czytelności menu
  { path: 'user', component: UserProfile},
  { path: 'profile', component: UserProfile},

  // Stan 3: Obsługa "pustego wejścia"
  // Bardzo ważne: pathMatch: 'full' oznacza, że przekierowanie zadziała 
  // TYLKO gdy adres URL jest dokładnie pusty (np. localhost:4200/). 
  // Bez tego każde żądanie mogłoby zostać "pochłonięte" przez login.
  { path: '', redirectTo: 'login', pathMatch: 'full' }, 

  // Stan 4: "Failsafe" (Obsługa błędnego adresu)
  // Gwiazdki '**' to tzw. Wildcard. Każdy adres niepasujący do powyższych
  // (np. localhost:4200/nieistnieje) zostanie przekierowany do logowania.
  { path: '**', redirectTo: 'login' }
];