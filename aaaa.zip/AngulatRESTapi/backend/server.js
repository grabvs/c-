// server.js
const express = require('express');
const Database = require('better-sqlite3');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const cors = require('cors');

const app = express();
const db = new Database('database.db');
const SECRET = 'sekretne_haslo_jwt';

app.use(express.json());
app.use(cors());

// Inicjalizacja bazy
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password TEXT,
    role TEXT DEFAULT 'user',s
    active INTEGER DEFAULT 1,
    firstName TEXT,
    lastName TEXT,
    age INTEGER,
    job TEXT
  )

  CREATE TABLE IF NOT EXISTS klienci (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    imie     TEXT,
    nazwisko TEXT,
    email    TEXT UNIQUE,
    telefon  TEXT
  );
 
  CREATE TABLE IF NOT EXISTS gokarty (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    numer  TEXT UNIQUE,
    model  TEXT,
    status TEXT DEFAULT 'dostepny'   -- wartości: 'dostepny' | 'zajety'
  );
 
  CREATE TABLE IF NOT EXISTS terminy (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    data         DATE    NOT NULL,
    start        TIME    NOT NULL,
    koniec       TIME    NOT NULL,
    ile_gokartow INTEGER NOT NULL,
    dostepny     INTEGER DEFAULT 1   -- 1 = wolny, 0 = zablokowany
  );
 
  CREATE TABLE IF NOT EXISTS rezerwacje (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    klient_id  INTEGER NOT NULL,
    termin_id  INTEGER NOT NULL,
    l_gokartow INTEGER NOT NULL,
    cena       REAL,
    uwagi      TEXT,
    FOREIGN KEY (klient_id) REFERENCES klienci(id),
    FOREIGN KEY (termin_id) REFERENCES terminy(id)
  );
 
  CREATE TABLE IF NOT EXISTS rezerwacje_gokartow (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    rezerwacja_id INTEGER NOT NULL,
    gokart_id     INTEGER NOT NULL,
    FOREIGN KEY (rezerwacja_id) REFERENCES rezerwacje(id),
    FOREIGN KEY (gokart_id)     REFERENCES gokarty(id)
`);

const seedAdmin = () => {
    const adminEmail = 'admin@test.pl';
    // Sprawdzamy czy admin już istnieje
    const admin = db.prepare('SELECT id FROM users WHERE role = ?').get('admin');

    if (!admin) {
    const salt = bcrypt.genSaltSync(10);
    const hashedPassword = bcrypt.hashSync('admin123', salt);
    
    db.prepare('INSERT INTO users (email, password, role, active) VALUES (?, ?, ?, ?)')
      .run(adminEmail, hashedPassword, 'admin', 1); // ZMIANA: tutaj było 'admin123' zamiast hashedPassword
    
    console.log(`[Database] Utworzono domyślnego admina: ${adminEmail}`);
}
};

seedAdmin();



// Middleware do weryfikacji JWT
const auth = (req, res, next) => {
    const token = req.headers['authorization']; // Pobranie tokena z nagłówka
    if (!token) return res.status(403).send('Brak tokenu');

    jwt.verify(token, SECRET, (err, decoded) => {
        if (err) return res.status(401).send('Brak autoryzacji');
        req.user = decoded; // Wypakowanie danych (id, role) do obiektu żądania
        next(); // Przejście do właściwej funkcji endpointu
    });
};



// Definicja endpointu logowania metodą POST
app.post('/api/login', (req, res) => {
    // Ekstrakcja danych z ciała żądania (destrukturyzacja obiektu)
    const { email, password } = req.body;

    // Przygotowanie i wykonanie zapytania do SQLite (better-sqlite3)
    // Używamy bindowania parametru (?) aby zapobiec atakom SQL Injection
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    
    // Logika weryfikacji (Bramka logiczna AND):
    // 1. Sprawdzenie czy użytkownik w ogóle istnieje w bazie
    // 2. Porównanie hasła z hashem przy użyciu bcrypt (bezpieczne porównanie odporne na timing attacks)
    // 3. Weryfikacja flagi 'active' - blokada dostępu dla zdezaktywowanych kont
    if (user && bcrypt.compareSync(password, user.password) && user.active) {
        
        // Generowanie tokena JWT (JSON Web Token):
        // Payload zawiera ID i rolę (do autoryzacji w kolejnych żądaniach)
        // Całość podpisana kluczem SECRET, co gwarantuje niezmienność danych (integralność)
        const token = jwt.sign({ id: user.id, role: user.role }, SECRET);
        
        // Wysłanie odpowiedzi sukcesu z tokenem i rolą (do logiki routingu na froncie)
        res.json({ token, role: user.role });
    } else {
        // W przypadku błędu wysyłamy status 401 (Unauthorized)
        // Ważne: Komunikat jest ogólny, aby nie zdradzać czy błędny jest email czy hasło (bezpieczeństwo)
        res.status(401).send('Nieprawidłowe dane logowania lub nieaktywne konto');
    }
});



// Admin: Dodawanie nowego klienta
app.post('/api/admin/clients', auth, (req, res) => {
    // 1. Autoryzacja - tylko admin może dodawać
    if (req.user.role !== 'admin') {
        return res.status(403).send('Zakaz: Wymagany dostęp administratora');
    }

    const { email, password } = req.body;

    // 2. Walidacja wejścia
    if (!email || !password) {
        return res.status(400).send('Email i hasło są wymagane');
    }

    try {
        // 3. Hashowanie hasła przed zapisem 
        const hashedPassword = bcrypt.hashSync(password, 10);

        // 4. Próba zapisu do bazy
        const stmt = db.prepare('INSERT INTO users (email, password, role, active) VALUES (?, ?, ?, ?)');
        const info = stmt.run(email, hashedPassword, 'user', 1);

        res.status(201).json({ id: info.lastInsertRowid, message: 'Klient dodany pomyślnie' });
    } catch (err) {
        // Obsługa błędu unikalności emaila (UNIQUE constraint w SQLite)
        if (err.message.includes('UNIQUE ...')) {
            return res.status(409).send('Taki użytkownik już istnieje');
        }
        res.status(500).send('Błąd serwera');
    }
});

// Admin: Pobranie wszystkich klientów
app.get('/api/admin/clients', auth, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).send('Zakaz: Wymagany dostęp administratora');
    const clients = db.prepare("SELECT * FROM users WHERE role = 'user'").all();
    res.json(clients);
});

// Admin: Zmiana statusu aktywności
app.patch('/api/admin/clients/:id', auth, (req, res) => {
    // 1. Sprawdzamy co przyszło (diagnostyka)
    const { active } = req.body;
    const clientId = req.params.id;
    
    console.log(`Próba zmiany statusu klienta ${clientId} na: ${active}`);

    try {
        // 2. Przygotowanie zapytania
        const stmt = db.prepare('UPDATE users SET active = ? WHERE id = ?');
        
        // 3. Wykonanie i przechwycenie wyniku
        // Używamy Number(active), aby upewnić się, że wysyłamy 0 lub 1
        const info = stmt.run(active ? 1 : 0, clientId);

        if (info.changes > 0) {
            // Zmieniamy sendStatus na .json, aby Angular poprawnie odebrał odpowiedź
            res.json({ success: true, message: 'Status zaktualizowany' });
        } else {
            res.status(404).json({ error: 'Nie znaleziono użytkownika o takim ID' });
        }
    } catch (err) {
        console.error('Błąd bazy danych:', err);
        res.status(500).json({ error: 'Błąd serwera' });
    }
});

// Klient: Aktualizacja własnych danych
app.put('/api/user/profile', auth, (req, res) => {
    const { firstName, lastName, age, job } = req.body;
    const userId = req.user.id; 

    try {
        const stmt = db.prepare(`
            UPDATE users 
            SET firstName = ?, lastName = ?, age = ?, job = ? 
            WHERE id = ?
        `);
        stmt.run(firstName, lastName, age || null, job, userId);
        
        // Zwracamy JSON, żeby Angular nie miał problemów z "Unexpected token O"
        res.status(200).json({ message: 'Profil zaktualizowany' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Błąd bazy danych' });
    }
});

// server.js - dodaj ten endpoint
app.get('/api/user/profile', auth, (req, res) => {
    const user = db.prepare('SELECT email, firstName, lastName, age, job FROM users WHERE id = ?')
                  .get(req.user.id);
    if (user) {
        res.json(user);
    } else {
        res.status(404).json({ error: 'Użytkownik nie istnieje' });
    }
});

// Admin: Usuwanie klienta
app.delete('/api/admin/clients/:id', auth, (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Brak uprawnień' });
    }

    const userId = req.params.id;

    try {
        const stmt = db.prepare('DELETE FROM users WHERE id = ? AND role = ?');
        const result = stmt.run(userId, 'user');

        if (result.changes > 0) {
            res.json({ message: 'Użytkownik został usunięty' });
        } else {
            res.status(404).json({ error: 'Nie znaleziono klienta' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Błąd bazy danych' });
    }
});

// ─────────────────────────────────────────────────────────────
// Pobranie dostępnych terminów (dla formularza rezerwacji)
// GET /api/terminy
// Zwraca tylko terminy z dostepny = 1, posortowane chronologicznie
// ─────────────────────────────────────────────────────────────
app.get('/api/terminy', auth, (req, res) => {
  try {
    const terminy = db.prepare(`
      SELECT id, data, start, koniec, ile_gokartow
      FROM terminy
      WHERE dostepny = 1
      ORDER BY data, start
    `).all();
    res.json(terminy);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Błąd serwera' });
  }
});
 
 
// ─────────────────────────────────────────────────────────────
// Tworzenie nowej rezerwacji
// POST /api/rezerwacje
// Body: { klient_id, termin_id, l_gokartow, uwagi? }
//
// Cała operacja wykonuje się w transakcji (db.transaction):
//   1. Sprawdza czy termin istnieje i jest dostępny
//   2. Sprawdza czy w terminie są jeszcze wolne miejsca
//   3. Pobiera wolne gokarty z tabeli gokarty
//   4. Tworzy rekord w rezerwacje
//   5. Tworzy powiązania w rezerwacje_gokartow
//   6. Zmienia status zajętych gokartów na 'zajety'
//   7. Blokuje termin (dostepny = 0) jeśli nie ma już wolnych miejsc
// ─────────────────────────────────────────────────────────────
app.post('/api/rezerwacje', auth, (req, res) => {
  // klient_id pochodzi z tokenu JWT — klient zawsze rezerwuje na siebie,
  // admin może podać klient_id jawnie w body (np. rezerwacja w imieniu klienta)
  const klient_id = req.user.role === 'admin' && req.body.klient_id
    ? req.body.klient_id
    : req.user.id;
 
  const { termin_id, l_gokartow, uwagi } = req.body;
 
  if (!termin_id || !l_gokartow || l_gokartow < 1) {
    return res.status(400).json({ error: 'Wymagane: termin_id, l_gokartow (min. 1)' });
  }
 
  try {
    const termin = db.prepare('SELECT * FROM terminy WHERE id = ? AND dostepny = 1').get(termin_id);
    if (!termin) {
      return res.status(404).json({ error: 'Termin nie istnieje lub jest już zajęty' });
    }
 
    const zajete = db.prepare(`
      SELECT COALESCE(SUM(l_gokartow), 0) AS suma
      FROM rezerwacje WHERE termin_id = ?
    `).get(termin_id);
 
    const dostepneGokarty = termin.ile_gokartow - zajete.suma;
 
    if (l_gokartow > dostepneGokarty) {
      return res.status(409).json({
        error: `Niewystarczająca liczba gokartów. Dostępne: ${dostepneGokarty}`
      });
    }
 
    const wolneGokarty = db.prepare(
      "SELECT id FROM gokarty WHERE status = 'dostepny' LIMIT ?"
    ).all(l_gokartow);
 
    if (wolneGokarty.length < l_gokartow) {
      return res.status(409).json({ error: 'Brak wystarczającej liczby wolnych gokartów w flocie' });
    }
 
    const cena = l_gokartow * 50.00;
 
    const insertRezerwacja  = db.prepare(
      'INSERT INTO rezerwacje (klient_id, termin_id, l_gokartow, cena, uwagi) VALUES (?, ?, ?, ?, ?)'
    );
    const insertPowiazanie  = db.prepare(
      'INSERT INTO rezerwacje_gokartow (rezerwacja_id, gokart_id) VALUES (?, ?)'
    );
    const zajmijGokart      = db.prepare("UPDATE gokarty SET status = 'zajety' WHERE id = ?");
    const blokujTermin      = db.prepare('UPDATE terminy SET dostepny = 0 WHERE id = ?');
 
    const transakcja = db.transaction(() => {
      const info = insertRezerwacja.run(klient_id, termin_id, l_gokartow, cena, uwagi || null);
      const rezerwacjaId = info.lastInsertRowid;
 
      for (const gokart of wolneGokarty) {
        insertPowiazanie.run(rezerwacjaId, gokart.id);
        zajmijGokart.run(gokart.id);
      }
 
      if (dostepneGokarty - l_gokartow === 0) {
        blokujTermin.run(termin_id);
      }
 
      return rezerwacjaId;
    });
 
    const rezerwacjaId = transakcja();
 
    res.status(201).json({ message: 'Rezerwacja utworzona pomyślnie', id: rezerwacjaId, cena });
 
  } catch (err) {
    console.error('Błąd tworzenia rezerwacji:', err);
    res.status(500).json({ error: 'Błąd serwera' });
  }
});
 
 
// ─────────────────────────────────────────────────────────────
// Lista wszystkich rezerwacji (panel admina)
// GET /api/admin/rezerwacje
// JOIN z klienci i terminy — zwraca dane potrzebne do tabeli w UI
// ─────────────────────────────────────────────────────────────
app.get('/api/admin/rezerwacje', auth, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Brak uprawnień' });
 
  try {
    const rezerwacje = db.prepare(`
      SELECT
        r.id,
        r.l_gokartow,
        r.cena,
        r.uwagi,
        k.imie,
        k.nazwisko,
        k.email,
        k.telefon,
        t.data,
        t.start,
        t.koniec
      FROM rezerwacje r
      JOIN klienci k ON r.klient_id = k.id
      JOIN terminy  t ON r.termin_id  = t.id
      ORDER BY t.data DESC, t.start DESC
    `).all();
 
    res.json(rezerwacje);
  } catch (err) {
    console.error('Błąd pobierania rezerwacji:', err);
    res.status(500).json({ error: 'Błąd serwera' });
  }
});
 
 
// ─────────────────────────────────────────────────────────────
// Anulowanie rezerwacji (panel admina)
// DELETE /api/admin/rezerwacje/:id
//
// Transakcja cofa cały efekt rezerwacji:
//   1. Zwalnia gokarty (status → 'dostepny')
//   2. Usuwa powiązania z rezerwacje_gokartow
//   3. Usuwa rekord z rezerwacje
//   4. Odblokowuje termin (dostepny → 1)
// ─────────────────────────────────────────────────────────────
app.delete('/api/admin/rezerwacje/:id', auth, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Brak uprawnień' });
 
  const rezerwacjaId = req.params.id;
 
  try {
    const rezerwacja = db.prepare('SELECT * FROM rezerwacje WHERE id = ?').get(rezerwacjaId);
    if (!rezerwacja) {
      return res.status(404).json({ error: 'Rezerwacja nie istnieje' });
    }
 
    db.transaction(() => {
      db.prepare(`
        UPDATE gokarty SET status = 'dostepny'
        WHERE id IN (SELECT gokart_id FROM rezerwacje_gokartow WHERE rezerwacja_id = ?)
      `).run(rezerwacjaId);
 
      db.prepare('DELETE FROM rezerwacje_gokartow WHERE rezerwacja_id = ?').run(rezerwacjaId);
 
      db.prepare('DELETE FROM rezerwacje WHERE id = ?').run(rezerwacjaId);
 
      db.prepare('UPDATE terminy SET dostepny = 1 WHERE id = ?').run(rezerwacja.termin_id);
    })();
 
    res.json({ message: 'Rezerwacja anulowana, gokarty i termin zwolnione' });
 
  } catch (err) {
    console.error('Błąd anulowania rezerwacji:', err);
    res.status(500).json({ error: 'Błąd serwera' });
  }
});

// -------------------------------------------------------------------
app.listen(3000, () => console.log('Serwer backend działa na porcie 3000'));