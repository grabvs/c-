create table if not exists zawodnik(
	zawodnik	SERIAL primary key,
	nazwisko 	varchar(35) not NULL,
	pozycja 	varchar (15) not NULL,
	numer 		SMALLINT not NULL,
	wzrost 		SMALLINT not null
)

insert into zawodnik (nazwisko, pozycja, numer, wzrost) values 
('Morant', 'pg', '12', '187'),
('Sochan', 'pf', '10', '203'),
('Wembanyama', 'c', '1', '224'),
('LeBron', 'sf', '23', '206'),
('Curry', 'sg', '30', '188')


select * from zawodnik

create table if not exists sklad(
	sklad		SERIAL primary key,
	nazwisko 	varchar(35) not NULL,
	pozycja 	varchar (15) not NULL,
	numer 		SMALLINT not NULL
)





