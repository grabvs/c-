﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Npgsql;
using System.Data;


namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    

    public partial class MainWindow : Window
    {
        private string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=postgres;Database=klub";

        public MainWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM zawodnik";

                using (var cmd = new NpgsqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    zawodnicy.ItemsSource = dt.DefaultView;
                }
            }
        }


        private void btnDodaj_Click(object sender, RoutedEventArgs e)
        {
            var connStr = "Host=localhost;Username=postgres;Password=postgres;Database=klub";
            using var conn = new NpgsqlConnection(connStr);
            conn.Open();

            var cmd = new NpgsqlCommand("INSERT INTO zawodnicy (nazwisko, pozycja, numer, wzrost) VALUES (@nazwisko, @pozycja, @numer, @wzrost)", conn);
            cmd.Parameters.AddWithValue("nazwisko", nazwisko.Text);
            cmd.Parameters.AddWithValue("pozycja", ((ComboBoxItem)pozycja.SelectedItem).Content.ToString());
            cmd.Parameters.AddWithValue("numer", decimal.Parse(numer.Text));
            cmd.Parameters.AddWithValue("wzrost", decimal.Parse(wzrost.Text));

            cmd.ExecuteNonQuery();
            MessageBox.Show("Dodano!");
        }

    }
}