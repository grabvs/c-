﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.IO;
using System.Collections.Generic;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Thread Termometr;
        private Thread Analiza;
        private Thread Pliki;

        private readonly Random random = new Random();

        private int lacznieUtworzone = 0;
        private int lacznieUsuniete = 0;

        private readonly object fileLock = new object();

        public MainWindow()
        {
            InitializeComponent();
            StartThreads();
        }

        // thready
        private void StartThreads()
        {
            Termometr = new Thread(TermometrWorker)
            {
                IsBackground = true
            };
            Termometr.Start();

            Analiza = new Thread(AnalizaWorker)
            {
                IsBackground = true
            };
            Analiza.Start();

            Pliki = new Thread(PlikiWorker)
            {
                IsBackground = true
            };
            Pliki.Start();
        }

        // watek termometru
        private void TermometrWorker()
        {
            while (true)
            {
                int temperatura = random.Next(35, 96);
                Dispatcher.Invoke(() =>
                {
                    txtTemperatura.Text = temperatura + " °C";
                });
                Thread.Sleep(1000);
            }
        }

        // watek analizy
        private void AnalizaWorker()
        {
            while (true)
            {
                double value = random.NextDouble() * 99 + 1;
                Dispatcher.Invoke(() =>
                {
                    pbAnaliza.Value = value;
                });
                Thread.Sleep(2000);
            }
        }


        // watek plikow
        private void PlikiWorker()
        {
            while (true)
            {
                int ilePlikow = 0;

                Dispatcher.Invoke(() =>
                {
                    if (!int.TryParse(txtPlikiNaCykl.Text, out ilePlikow) || ilePlikow < 0)
                        ilePlikow = 0;
                });

                // katalog

                var utworzone = new List<string>();
                string katalog = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "pliki");
                Directory.CreateDirectory(katalog);

                // tworzenie plikow

                for (int i = 0; i < ilePlikow; i++)
                {
                    string nazwa = System.IO.Path.Combine(katalog, Guid.NewGuid().ToString("N") + ".txt");
                    File.WriteAllText(nazwa, "Plik testowy");
                    utworzone.Add(nazwa);
                }

                lock (fileLock)
                {
                    lacznieUtworzone += utworzone.Count;
                }

                // dodawanie plikow

                Dispatcher.Invoke(() =>
                {
                    listBoxPliki.Items.Clear();
                    foreach (var f in utworzone)
                        listBoxPliki.Items.Add(f);

                    txtUtworzone.Text = lacznieUtworzone.ToString();
                    txtUsuniete.Text = lacznieUsuniete.ToString();
                });
                Thread.Sleep(1000);

                // usuwanie plikow

                foreach (var f in utworzone)
                {
                    try
                    {
                        if (File.Exists(f))
                            File.Delete(f);
                    }
                    catch { }
                }

                lock (fileLock)
                {
                    lacznieUsuniete += utworzone.Count;
                }

                Dispatcher.Invoke(() =>
                {
                    txtUsuniete.Text = lacznieUsuniete.ToString();
                });

                Thread.Sleep(5000);
            }
        }

    }
}