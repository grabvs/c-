﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        private void MenuItem_Kopiuj(object sender, RoutedEventArgs e)
        {
            var textBox = Keyboard.FocusedElement as TextBox;
            if (textBox != null)
            {
                Clipboard.SetText($"{textBox.Text}");
            }
        }

        private void MenuItem_Wklej(object sender, RoutedEventArgs e)
        {
            var textBox = Keyboard.FocusedElement as TextBox;
            if (textBox != null)
            {
                textBox.Text += Clipboard.GetText();
            }
        }

        private int pozycja = 1;

        private void btnPozycja_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("dodano pozycje");

            MenuItem nowaPozycja = new MenuItem();
            nowaPozycja.Header = $"Pozycja nr: {pozycja}";
            nowaPozycja.Tag = pozycja;
            nowaPozycja.Click += Liczba;
            menuPozycja.Items.Add(nowaPozycja);
            pozycja++;
        }
        private void Liczba(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem item && item.Tag is int numer)
            {
                MessageBox.Show($"kliknieto: {numer}", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

    }
}
