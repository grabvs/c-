﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MenuItem_Kopiuj(object sender, RoutedEventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtBox1.Text))
            //{
            //    Clipboard.SetText(txtBox1.Text);
            //    MessageBox.Show("Skopiowano tekst do schowka");
            //}
            //else
            //{
            //    MessageBox.Show("nie masz zaznaczonego tekstu xdd", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            //}

            var textBox = ((sender as MenuItem).Parent as ContextMenu).PlacementTarget as TextBox;
            if(textBox != null)
            {
                Clipboard.SetText(textBox.Text);
            }
        }

        private void MenuItem_Wklej(object sender, RoutedEventArgs e)
        {
            //if (Clipboard.ContainsText())
            //{
            //    txtBox2.Text = Clipboard.GetText();
            //    MessageBox.Show("Skopiowano ze schowka");
            //}
            //else
            //{
            //    MessageBox.Show("brak tekstu xdd", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            //}

            var textBox = ((sender as MenuItem).Parent as ContextMenu).PlacementTarget as TextBox;
        }
    }
}