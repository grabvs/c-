﻿using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Npgsql;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //string ktory przechowuje dane logowania do bazy
        private string connectionString = "Host=localhost;Username=postgres;Password=postgres;Database=technikum;";
        public MainWindow()
        {
            InitializeComponent();
        }

        //dodawanie rekordow
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string imie = ImieTextBox.Text;
            string nazwisko = NazwiskoTextBox.Text;
            string plec = (PlecComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            DateTime? dataUr = DataUrDatePicker.SelectedDate;

            if (string.IsNullOrEmpty(imie) || string.IsNullOrEmpty(nazwisko) || string.IsNullOrEmpty(plec) || dataUr == null )
            {
                MessageBox.Show("nie wypelniono wszystkich pol", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    using (var cmd = new NpgsqlCommand("INSERT INTO uczen (imie, nazwisko, plec, data_ur) VALUES (@imie, @nazwisko, @plec, @data_ur)", connection))
                    {
                        cmd.Parameters.AddWithValue("imie", imie);
                        cmd.Parameters.AddWithValue("nazwisko", nazwisko);
                        cmd.Parameters.AddWithValue("plec", plec[0]);
                        cmd.Parameters.AddWithValue("data_ur", dataUr.Value);

                        cmd.ExecuteNonQuery();
                    }
                    connection.Close();
                }
                MessageBox.Show("dodano rekord do bazy", "dodanie ucznia", MessageBoxButton.OK, MessageBoxImage.Information);

                zaladujBaze();
                wyczyscDane();

            } catch (Exception ex)
            {
                MessageBox.Show("problem z dodaniem rekordu", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }
        //czyszczenie danych formularza
        private void wyczyscDane()
        {
            ImieTextBox.Clear();
            NazwiskoTextBox.Clear();
            PlecComboBox.SelectedIndex = -1;
            DataUrDatePicker.SelectedDate = null;
        }

        //laczenie z baza i wyswietlenie aktualnych rekordow
        private void zaladujBaze()
        {
            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    using (var cmd = new NpgsqlCommand("SELECT * from uczen", connection))
                    {
                        using (var reader = cmd.ExecuteReader())
                        {
                            DataTable uczniowieTable = new DataTable();
                            uczniowieTable.Load(reader);
                            UczniowieDataGrid.ItemsSource = uczniowieTable.DefaultView;
                        }
                    }

                    connection.Close();
                }
            } catch (Exception e)
            {
                MessageBox.Show($"wystapil blad polaczenia z baza {e}");
            }
        }

        private void Button_Click_1 (object sender, RoutedEventArgs e)
        {
            if (wybranyUczen == null)
            {
                MessageBox.Show("Nie wybrano ucznia", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    using (var cmd = new NpgsqlCommand("DELETE FROM uczen WHERE uczen = @id", connection))
                    {
                        cmd.Parameters.AddWithValue("id", wybranyUczen.Id);
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Usunięto ucznia", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        else
                        {
                            MessageBox.Show("Nie znaleziono ucznia w bazie", "Błąd", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    }
                    connection.Close();
                }

                zaladujBaze();
                wyczyscDane();
                wybranyUczen = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Błąd podczas usuwania ucznia", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        public class Uczen
        {
            public int Id { get; set; }
            public string imie { get; set; }
            public string nazwisko { get; set; }
            public char plec { get; set; }
            public DateTime dataUr { get; set; }
        }

        private Uczen wybranyUczen;

        private void UczenDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            wybranyUczen = UczniowieDataGrid.SelectedItem as Uczen;
        }

    }
}