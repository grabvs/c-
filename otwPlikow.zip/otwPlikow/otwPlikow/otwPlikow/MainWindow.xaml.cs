﻿using System.IO;
using System.Reflection.Emit;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace otwPlikow
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string selectedPath;
        private string newPath;
        private DispatcherTimer timer;

        public object NewNameTextBox { get; private set; }
        public object OldNameTextBox { get; private set; }

        public MainWindow()
        {
            InitializeComponent();
            StartClock();
            LoadFolderTree();
        }

        private void LoadFolderTree()
        {
            foreach (var drive in Directory.GetLogicalDrives())
            {
                var driveItem = new TreeViewItem
                {
                    Header = drive,
                    Tag = drive
                };
                driveItem.Expanded += Folder_Expanded;
                FolderTreeView.Items.Add(driveItem);
            }
        }

        private void RefreshTree()
        {
            FolderTreeView.Items.Clear();
            LoadFolderTree();
        }

        private void Folder_Expanded(object sender, RoutedEventArgs e)
        {
            var item = (TreeViewItem)sender;
            if (item.Items.Count != 0) return;
            item.Items.Clear();

            var fullPath = (string)item.Tag;

            try
            {
                var directories = Directory.GetDirectories(fullPath);
                foreach (var dir in directories)
                {
                    var subItem = new TreeViewItem
                    {
                        Header = System.IO.Path.GetFileName(dir),
                        Tag = dir
                    };

                    subItem.Expanded += Folder_Expanded;
                    item.Items.Add(subItem);
                }

                var files = Directory.GetFiles(fullPath);
                foreach (var file in files) {
                    var subItem = new TreeViewItem
                    {
                        Header = System.IO.Path.GetFileName(file),
                    };
                }     
                

            }catch (Exception ex)
            {
                MessageBox.Show("problem z katalogiem", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FolderTreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            var selectedItem = (TreeViewItem)FolderTreeView.SelectedItem;
            if (selectedItem != null)
            {
               selectedPath = (string)selectedItem.Tag;
               SelectedPathTextBox.Text = selectedPath;
               RenameTextBox.Text = System.IO.Path.GetFileName(selectedPath);
            }
        }

        private void RenameButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(selectedPath) || string.IsNullOrEmpty(RenameTextBox.Text))
            {
                MessageBox.Show("Wybierz element do zmiany nazwy", "Uwaga", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string newPath = "";
            try
            {
                var directoryPath = System.IO.Path.GetDirectoryName(selectedPath);
                newPath = System.IO.Path.Combine(directoryPath, RenameTextBox.Text);

                if (File.Exists(selectedPath))
                {
                    File.Move(selectedPath, newPath);
                }
                else if (Directory.Exists(selectedPath))
                {
                    Directory.Move(selectedPath, newPath);
                }


                MessageBox.Show("Nazwa zmieniona", "Zmiana nazwy", MessageBoxButton.OK, MessageBoxImage.Information);
                selectedPath = newPath;
                SelectedPathTextBox.Text = selectedPath;
                RenameTextBox.Text = System.IO.Path.GetFileName(selectedPath);
                RefreshTree();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Problem ze zmianą nazwy", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void StartClock()
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            labelDate.Items.Clear();
            labelDate.Items.Add(DateTime.Now.ToString("dddd, dd MMMM yyyy, HH:mm:ss"));

        }


    }
}