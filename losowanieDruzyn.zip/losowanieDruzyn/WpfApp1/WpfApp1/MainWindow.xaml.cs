﻿using Microsoft.Win32;
using System.IO;
using System.Text;
using System.Text.Json.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.Json;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Uczen> uczen = new List<Uczen>();
        Random rnd = new Random();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLoad_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "plik tekstowy (*.txt; *.json)| *.txt; *.json";
            ofd.Title = "wybor pliku z uczniami";
            if (ofd.ShowDialog() == true)
            {
                try
                {
                    string path = ofd.FileName;
                    string ext = System.IO.Path.GetExtension(path).ToLower();
                    if (ext == ".txt")
                    {
                        wczytajPlikTxt(path);
                        MessageBox.Show("wczytano plik txt", "git", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else if (ext == ".json")
                    {
                        wczytajPlikJson(path);
                        MessageBox.Show("wczytano plik json", "git", MessageBoxButton.OK, MessageBoxImage.Information);

                    } else
                    {
                        MessageBox.Show("wybrano nieobslugiwane rozszerzenie", "blad", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("blad: " + ex.Message);
                }
            }
        }

        private void wczytajPlikTxt(string path)
        {
            var lines = File.ReadAllLines(path);
            uczen.Clear();

            foreach (var line in lines)
            {
                if (string.IsNullOrEmpty(line)) continue;

                var dane = line.Split(';');
                if (dane.Length != 4) continue;

                uczen.Add(new Uczen
                {
                    imie = dane[0],
                    nazwisko = dane[1],
                    klasa = dane[2],
                    punkty = int.Parse(dane[3])
                });
            }
            MessageBox.Show(uczen.ToString());
        }

        private void wczytajPlikJson(string path)
        {
            string content = File.ReadAllText(path);
            var opcje = new JsonSerializerOptions { PropertyNameCaseSensity = true };
            uczen = JsonSerializer.Deserialize<List<Uczen>>(content, opcje);
        }



        private void btnLosujSiatke_Click(object sender, RoutedEventArgs e)
        {
            if(uczen.Count < 14)
            {
                MessageBox.Show("za malo uczniow");
                return;
            }

            List<Uczen> pilkarze = new List<Uczen>();

            for (int i = 0; i > 14; i++) {
                var wylosowani = uczen[rnd.Next(1, 30)];
                pilkarze.Add(wylosowani);
            }

            List<Uczen> rezerwowi = new List<Uczen>();
            foreach(var pilkarz in pilkarze)
            {
                //var rezerwowi = pilkarze[rnd.Next(1, 14)];
                
            }
        }

        private void btnLosujPilke_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}