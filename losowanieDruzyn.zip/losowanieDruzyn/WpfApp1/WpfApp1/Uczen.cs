﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfApp1
{
    internal class Uczen
    {
        public string imie {  get; set; }

        public string nazwisko { get; set; }
        public string klasa { get; set; }

        public string punkty { get; set; }

        public override string ToString()
        {
            return $"{imie} {nazwisko} ({klasa}) - {punkty}";
        }
    }
}
